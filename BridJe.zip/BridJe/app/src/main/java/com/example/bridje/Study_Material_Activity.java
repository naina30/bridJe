package com.example.bridje;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Study_Material_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study__material_);
    }
}
