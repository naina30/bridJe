package com.example.bridje;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class cgpaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cgpa);
    }
}
