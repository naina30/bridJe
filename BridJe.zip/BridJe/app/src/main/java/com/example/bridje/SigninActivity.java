package com.example.bridje;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SigninActivity extends AppCompatActivity {
    private EditText pass;
    private Button logIn;
    private EditText enr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
        pass=(findViewById(R.id.editText2));
        enr=(findViewById(R.id.editText));
        logIn=(findViewById(R.id.button));

    }
}
